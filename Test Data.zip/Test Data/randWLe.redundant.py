import random

# this module generates a random W-L-e matrix

vcount = 80
candCount = 24000

matrix = []
for candi in range(candCount):
    wcount = 0
    while wcount == 0:
        wcount = random.randrange(vcount)
    wset = {random.randrange(vcount) for _ in range(wcount)}
    wset = list(wset)
    wset.sort()
    wcount = len(wset)

    lcount = random.randrange(vcount)
    lset = set()
    if wset[wcount - 1] > 0:
        lset = {random.randrange(wset[wcount - 1]) for _ in range(lcount)}
    lcount = len(lset)

    line = ['e'] * vcount
    for w in wset: line[w] = 'w'
    for l in lset:
        if line[l] == 'e': line[l] = 'l'

    matrix.append(' '.join(line) + '\n')


fout = open("c%d-e%d.txt" % (vcount, candCount), "w")
fout.writelines(matrix)
fout.close()                  

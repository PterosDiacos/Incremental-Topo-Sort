import random
import time

# this module generates a non-redundant random W-L-e matrix

lasttime = time.time()
vcount = 400
vDiv = 5
candCount = 720


def sort(space, conjunction):
    nonzeroin = {x for [wset, x] in conjunction}
    zeroin = space - nonzeroin
    topsort = []
    #Kahn's algorithm
    while len(zeroin) > 0:
        topsort.append(zeroin)
        conjunction = [[wset, x] for [wset, x] in conjunction
                                 if len(wset & zeroin) == 0]
        nonzeroin = {x for [wset, x] in conjunction}
        space = space - zeroin
        zeroin = space - nonzeroin

    if len(nonzeroin) == 0: return topsort
    else: return []




space = {i for i in range(vcount)}
conjunction = []
matrix = []
lastRank = [space]

candi = 0
tier = 0
while candi in range(candCount):
    wcount = 0
    while wcount == 0:
        wcount = random.randrange(vcount)
    wset = {random.randrange(vcount // vDiv * (tier), vcount // vDiv * (tier + 1)) for _ in range(wcount)}
    wmax = max(wset)

    lcount = random.randrange(vcount)
    lset = set()
    if wmax > vcount // vDiv * (tier):
        lset = {random.randrange(vcount // vDiv * (tier), wmax) for _ in range(lcount)}
    lset = lset - wset

    line = ['e'] * vcount
    for w in wset: line[w] = 'w'
    for l in lset: line[l] = 'l'
    
    conjunction1 = conjunction + [[wset, x] for x in lset]
    test = sort(space, conjunction1)
    if test != lastRank:
        candi += 1
        print(candi, '/', candCount, len(test), end = '\n')
        matrix.append(' '.join(line) + '\n')
        conjunction = conjunction1
        lastRank = test
        if len(lastRank) == vcount:
            break
##        elif len(lastRank) >= vcount // vDiv * (tier + 1):
##            if vDiv > 1:
##                if tier + 1 < vDiv:
##                    tier += 1
##                else:
##                    tier = 0
##                    vDiv -= 1
##                lasttime = time.time()
##                continue

    if time.time() - lasttime > 300:
        tokill = input("5 min passed on (tier %d, div %d). Moving on? (y/n) " % (tier, vDiv))       
        if tokill == 'n': break
        else:
            if vDiv > 1:
                if tier + 1 < vDiv:
                    tier += 1
                else:
                    tier = 0
                    vDiv -= 1
            lasttime = time.time()
    
    
print('')
fout = open("c%d-nr%d.txt" % (vcount, len(matrix)), "w")
fout.writelines(matrix)
fout.close()                  
